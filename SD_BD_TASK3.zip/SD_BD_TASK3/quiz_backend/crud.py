from sqlalchemy.orm import Session
from passlib.hash import bcrypt
import models, schemas

def create_user(db: Session, user: schemas.UserCreate):
    hashed_pw = bcrypt.hash(user.password)
    db_user = models.User(username=user.username, hashed_password=hashed_pw)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_user_by_username(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()

def get_questions(db: Session):
    return db.query(models.Question).all()

def calculate_score(db: Session, quiz_data: schemas.QuizSubmit):
    score = 0
    for ans in quiz_data.answers:
        q = db.query(models.Question).filter(models.Question.id == ans.question_id).first()
        if q and q.correct_answer.lower() == ans.answer.lower():
            score += 1
    result = models.Result(user_id=quiz_data.user_id, score=score)
    db.add(result)
    db.commit()
    return score

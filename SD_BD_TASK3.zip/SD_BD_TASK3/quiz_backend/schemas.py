from pydantic import BaseModel
from typing import List

class UserCreate(BaseModel):
    username: str
    password: str

class UserOut(BaseModel):
    id: int
    username: str
    class Config:
        orm_mode = True

class QuestionOut(BaseModel):
    id: int
    question_text: str
    class Config:
        orm_mode = True

class AnswerIn(BaseModel):
    question_id: int
    answer: str

class QuizSubmit(BaseModel):
    user_id: int
    answers: List[AnswerIn]
